const express = require("express")
const jwt = require("jsonwebtoken")
const router = express.Router()
require("dotenv").config()

const {
  getUserProducts,
  registration,
  obtainUser,
  verifyUser,
  getProducts,
  getProductByCategory,
  getCartProducts,
  createProduct,
  allUsers,
} = require("../consultas/consultas")
const {
  checkCredentialsExist,
  tokenVerification,
} = require("../middleware/middleware")

router.get("/", (req, res) => {
  res.send("Hello World")
})

router.post("/usuarios", checkCredentialsExist, async (req, res) => {
  try {
    const usuarios = req.body
    await registration(usuarios)
    res.send("Usuario registrado con éxito!")
  } catch (error) {
    res.status(500).send(error)
  }
})

router.get("/usuarios", tokenVerification, async (req, res) => {
  try {
    const Authorization = req.header("Authorization")
    const token = Authorization.split("Bearer ")[1]
    const { email } = jwt.decode(token)
    const usuario = await obtainUser(email)
    res.json(usuario)
  } catch (error) {
    res.status(500).send(error)
  }
})

router.get("/todos", async (req, res) => {
  try {
    const usuarios = await allUsers()
    res.json(usuarios)
  } catch (error) {
    res.status(500).send(error)
  }
})

router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body
    const userId = await verifyUser(email, password)

    const token = jwt.sign({ email, id: userId }, process.env.SECRET)

    res.json({ email, token, id: userId })
  } catch (error) {
    res
      .status(error.code || 500)
      .json({ message: error.message || "Error en el servidor" })
  }
})

router.get("/products", async (req, res) => {
  try {
    const products = await getProducts()
    res.json(products)
  } catch (error) {
    res.status(500).send(error)
  }
})

router.post("/products", async (req, res) => {
  console.log("Datos del producto a insertar:", req.body)
  try {
    const productos = req.body
    await createProduct(productos)
    res.send("Producto Agregado con Éxito")
  } catch (error) {
    res.status(500).send(error)
  }
})

router.get("/user-posts/:user_id", async (req, res) => {
  try {
    const user_id = req.params.user_id
    const userProducts = await getUserProducts(user_id)
    res.json(userProducts)
  } catch (error) {
    console.error(error)
    res
      .status(500)
      .json({ message: "Error al obtener las publicaciones del usuario" })
  }
})

router.get("/products/category/:category", async (req, res) => {
  try {
    const category = req.params.category
    const products = await getProductByCategory(category)
    res.json(products)
  } catch (error) {
    console.error("Error al procesar la solicitud:", error)

    res.status(500).send(error)
  }
})

router.get("/:id", async (req, res) => {
  try {
    const productId = req.params.id
    const product = await obtainProductById(productId)

    if (product) {
      res.json(product)
    } else {
      res.status(404).json({ message: "Producto no encontrado" })
    }
  } catch (error) {
    console.error(error)
    res.status(500).json({ error: "Error al obtener el producto" })
  }
})

router.get("/cart", async (req, res) => {
  try {
    let userId = null
    const { userId: queryUserId, isAuthenticated } = req.query

    if (isAuthenticated === "true" && queryUserId) {
      userId = queryUserId
    } else if (isAuthenticated === "false" && !queryUserId) {
    } else {
      throw new Error("Usuario no autenticado o falta de parámetros")
    }

    const cartProducts = await getCartProducts(userId)
    res.json(cartProducts)
  } catch (error) {
    res.status(500).json({
      error:
        error.message ||
        "Error al obtener los productos del carrito de compras",
    })
  }
})
module.exports = router
